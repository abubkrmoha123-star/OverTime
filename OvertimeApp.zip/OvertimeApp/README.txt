How to build the app:
1. Install Android Studio (free).
2. File > Open > choose the OvertimeApp folder, wait for Gradle sync to finish.
3. Connect your phone with USB debugging on, then press the green Run button.
4. For an installable APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
PDFs are saved in the phone's Downloads folder.
